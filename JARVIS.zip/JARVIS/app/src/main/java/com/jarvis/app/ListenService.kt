package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/** "Hey Jarvis" सुनता रहता है, फिर आपकी कमांड चलाता है */
class ListenService : Service() {
    private lateinit var rec: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var cmds: Commands
    private val h = Handler(Looper.getMainLooper())
    private var awaiting = false
    private var running = false

    private val wake = Regex("hey jarvis|jarvis|जार्विस|जारविस|जर्विस|जरविस|जार्विज|जार्विश")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (running) return START_STICKY
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel("jarvis", "JARVIS", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("JARVIS सुन रहा है")
            .setContentText("\"Hey Jarvis\" बोलिए")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)

        tts = TextToSpeech(this) { tts.language = Locale("hi", "IN") }
        cmds = Commands(this) { s -> tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, null) }

        rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) process(t)
                again(1200)
            }
            override fun onError(e: Int) {
                again(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 2500 else 800)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        again(500)
        return START_STICKY
    }

    private fun process(text: String) {
        val c = text.lowercase()
        if (awaiting) { awaiting = false; cmds.handle(text); return }
        if (wake.containsMatchIn(c)) {
            val rest = c.replace(wake, "").replace("hey", "").replace("हे", "").trim()
            if (rest.isBlank()) {
                awaiting = true
                tts.speak("जी, बोलिए", TextToSpeech.QUEUE_FLUSH, null, null)
            } else cmds.handle(rest)
        }
    }

    private fun again(delay: Long) {
        h.postDelayed({
            if (!running) return@postDelayed
            try {
                rec.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                })
            } catch (e: Exception) { again(2000) }
        }, delay)
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        rec.destroy(); tts.shutdown()
        super.onDestroy()
    }
}
