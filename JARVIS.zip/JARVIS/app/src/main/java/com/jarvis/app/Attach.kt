package com.jarvis.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream

data class Att(val mime: String?, val b64: String?, val text: String?)

object Attach {
    fun load(ctx: Context, uri: Uri): Att {
        val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
        val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        return when {
            mime.startsWith("image/") -> {
                var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                val max = 1600
                val s = max.toFloat() / maxOf(bmp.width, bmp.height)
                if (s < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
                val o = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 85, o)
                Att("image/jpeg", Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP), null)
            }
            mime == "application/pdf" ->
                Att(mime, Base64.encodeToString(bytes, Base64.NO_WRAP), null)
            else -> Att(null, null, String(bytes).take(50000))
        }
    }
}
