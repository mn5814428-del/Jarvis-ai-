package com.jarvis.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var tts: TextToSpeech
    private lateinit var rec: SpeechRecognizer
    private lateinit var out: TextView
    private lateinit var input: EditText
    private lateinit var cmds: Commands
    private var photoUri: Uri? = null
    private var wakeOn = false

    private val pickFile = registerForActivityResult(ActivityResultContracts.GetContent()) { u ->
        u?.let { sendUri(it) }
    }
    private val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) photoUri?.let { sendUri(it) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        out = TextView(this).apply { textSize = 18f; text = "JARVIS तैयार है" }
        input = EditText(this).apply { hint = "फोटो/फाइल के बारे में सवाल (वैकल्पिक)" }

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        val wakeBtn = btn("👂 Hey Jarvis मोड: बंद") {}
        wakeBtn.setOnClickListener {
            wakeOn = !wakeOn
            val i = Intent(this, ListenService::class.java)
            if (wakeOn) startForegroundService(i) else stopService(i)
            wakeBtn.text = "👂 Hey Jarvis मोड: " + if (wakeOn) "चालू" else "बंद"
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL; setPadding(40, 40, 40, 40)
            addView(ScrollView(this@MainActivity).apply {
                addView(out)
            }, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(input)
            addView(btn("🎤 बोलिए") { listen() })
            addView(btn("📷 कैमरा से पूछो") { takeCamera() })
            addView(btn("📎 फाइल / PDF / फोटो चुनो") { pickFile.launch("*/*") })
            addView(wakeBtn)
            addView(btn("⚙️ परमिशन: Overlay") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            })
            addView(btn("♿ Accessibility ON करें") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
        }
        setContentView(col)

        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
            Manifest.permission.CAMERA, Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, perms.toTypedArray(), 1)

        tts = TextToSpeech(this) { tts.language = Locale("hi", "IN") }
        cmds = Commands(this) { say(it) }
        cmds.onCamera = { runOnUiThread { takeCamera() } }

        rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                out.text = "आप: $t"
                cmds.handle(t)
            }
            override fun onError(e: Int) { out.text = "समझ नहीं आया, दोबारा बोलिए" }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
    }

    private fun listen() {
        rec.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        })
    }

    private fun say(s: String) {
        runOnUiThread { out.text = "JARVIS: $s" }
        tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    private fun takeCamera() {
        val dir = File(cacheDir, "images").apply { mkdirs() }
        val f = File(dir, "cam.jpg")
        photoUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        takePhoto.launch(photoUri)
    }

    /** फोटो / PDF / टेक्स्ट फाइल Claude को भेजकर समझवाता है */
    private fun sendUri(uri: Uri) {
        val q = input.text.toString().ifBlank { "इसमें क्या है? हिंदी में आसान भाषा में समझाओ।" }
        out.text = "समझ रहा हूँ..."
        thread {
            try {
                val a = Attach.load(this, uri)
                if (a.text != null) Claude.ask("$q\n\n--- फाइल ---\n${a.text}") { say(it) }
                else Claude.ask(q, a.mime, a.b64) { say(it) }
            } catch (e: Exception) { say("फाइल पढ़ नहीं पाया") }
        }
    }

    override fun onDestroy() { rec.destroy(); tts.shutdown(); super.onDestroy() }
}
