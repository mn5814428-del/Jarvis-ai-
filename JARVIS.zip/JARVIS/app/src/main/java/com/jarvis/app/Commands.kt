package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager

class Commands(private val ctx: Context, private val say: (String) -> Unit) {

    var onCamera: (() -> Unit)? = null

    private val alias = mapOf(
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "यूट्यूब" to "youtube",
        "कैमरा" to "camera", "सेटिंग" to "settings", "सेटिंग्स" to "settings",
        "क्रोम" to "chrome", "गैलरी" to "gallery", "फोन" to "phone",
        "इंस्टाग्राम" to "instagram", "गूगल" to "google", "मैप" to "maps",
        "मैप्स" to "maps", "फेसबुक" to "facebook", "टेलीग्राम" to "telegram"
    )
    private val stopOpen = setOf("open", "खोलो", "खोल", "kholo", "ओपन", "करो", "कर", "दो", "app", "ऐप", "एप", "please", "प्लीज")
    private val stopClick = setOf("click", "दबाओ", "dabao", "press", "tap", "पर", "par", "बटन", "button")
    private val stopCall = setOf("call", "कॉल", "लगाओ", "lagao", "को", "ko", "करो", "karo", "कर", "दो", "फोन", "phone")
    private val stopMsg = setOf("whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "sms", "message", "मैसेज", "send", "पर", "pe", "से")

    private fun strip(s: String, stop: Set<String>) =
        s.split(" ").filter { it.isNotBlank() && it !in stop }.joinToString(" ").trim()

    private fun start(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    fun handle(raw: String) {
        val c = raw.lowercase().trim()
        val svc = JarvisService.instance
        fun has(vararg k: String) = k.any { c.contains(it) }
        fun needSvc(): Boolean { if (svc == null) say("पहले Accessibility में JARVIS ON करें"); return svc == null }

        // 1) नाम को मैसेज: "Rahul ko hello bhejo"
        val m = Regex("(.+?)\\s+(को|ko)\\s+(.+?)\\s+(भेजो|bhejo|bhej do|भेज दो|message|मैसेज)$").find(c)
        if (m != null && !has("call", "कॉल")) {
            val name = strip(m.groupValues[1], stopMsg)
            sendMessage(name, m.groupValues[3], has("whatsapp", "व्हाट्सएप", "व्हाट्सऐप")); return
        }

        // 2) कॉल (नंबर या नाम)
        if (has("call", "कॉल", "फोन लगाओ")) {
            val digits = c.filter { it.isDigit() }
            val num = if (digits.length >= 5) digits else findNumber(strip(c, stopCall))
            if (num == null) say("नंबर या नाम नहीं मिला")
            else { start(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num"))); say("कॉल लगा रहा हूँ") }
            return
        }

        // 3) कैमरा से देखो
        if (has("camera se", "कैमरा से", "dekho", "देखो")) {
            onCamera?.invoke() ?: say("JARVIS ऐप खोलकर कैमरा बटन दबाएँ"); return
        }

        // 4) स्क्रीन पढ़ना
        if (has("screen padho", "स्क्रीन पढ़ो", "read screen", "स्क्रीन पर क्या", "screen par kya")) {
            if (needSvc()) return
            val t = svc!!.readScreen()
            Claude.ask("यह मेरे फोन की स्क्रीन का टेक्स्ट है। हिंदी में छोटा सारांश बताओ:\n$t") { say(it) }
            return
        }

        // 5) ऐप खोलना
        if (has("open", "खोल", "kholo", "ओपन")) {
            var name = strip(c, stopOpen)
            alias.forEach { (k, v) -> name = name.replace(k, v) }
            if (openApp(name)) say("$name खोल रहा हूँ") else say("$name ऐप नहीं मिला")
            return
        }

        // 6) बटन दबाना
        if (has("click", "दबाओ", "dabao")) {
            if (needSvc()) return
            say(if (svc!!.clickText(strip(c, stopClick))) "हो गया" else "बटन नहीं मिला"); return
        }

        // 7) टाइप करना
        val t = Regex("(type|likho|लिखो)\\s+(.+)", RegexOption.IGNORE_CASE).find(raw)
        if (t != null) {
            if (needSvc()) return
            say(if (svc!!.typeText(t.groupValues[2])) "लिख दिया" else "पहले टेक्स्ट बॉक्स पर टैप करें"); return
        }

        // 8) स्क्रॉल
        if (has("scroll down", "नीचे", "niche")) { if (needSvc()) return; svc!!.scroll(true); return }
        if (has("scroll up", "ऊपर", "upar")) { if (needSvc()) return; svc!!.scroll(false); return }

        // 9) सिस्टम बटन
        when {
            has("home", "होम") -> { if (needSvc()) return; svc!!.global(AccessibilityService.GLOBAL_ACTION_HOME); return }
            has("back", "पीछे") -> { if (needSvc()) return; svc!!.global(AccessibilityService.GLOBAL_ACTION_BACK); return }
            has("notification", "नोटिफिकेशन") -> { if (needSvc()) return; svc!!.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); return }
            has("screenshot", "स्क्रीनशॉट") -> { if (needSvc()) return; svc!!.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT); return }
            has("recent", "रीसेंट") -> { if (needSvc()) return; svc!!.global(AccessibilityService.GLOBAL_ACTION_RECENTS); return }
            has("lock", "लॉक") -> { if (needSvc()) return; svc!!.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN); return }
        }

        // 10) टॉर्च, आवाज़, वाईफाई, ब्लूटूथ
        when {
            has("torch on", "flashlight on", "टॉर्च चालू", "टॉर्च जलाओ") -> { torch(true); say("टॉर्च चालू"); return }
            has("torch off", "flashlight off", "टॉर्च बंद") -> { torch(false); say("टॉर्च बंद"); return }
            has("volume up", "volume badhao", "वॉल्यूम बढ़ाओ", "आवाज़ बढ़ाओ", "आवाज बढ़ाओ") -> { vol(true); return }
            has("volume down", "volume kam", "वॉल्यूम कम", "आवाज़ कम", "आवाज कम") -> { vol(false); return }
            has("wifi", "वाईफाई", "वाई-फाई") -> { start(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)); say("वाईफाई पैनल खोला"); return }
            has("bluetooth", "ब्लूटूथ") -> { start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); say("ब्लूटूथ सेटिंग खोली"); return }
        }

        // 11) गूगल सर्च
        if (has("search", "सर्च", "गूगल")) {
            val q = c.replace(Regex("search|सर्च|गूगल"), "").trim()
            start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))); return
        }

        // 12) बाकी सब कुछ Claude से
        Claude.ask(raw) { say(it) }
    }

    private fun openApp(name: String): Boolean {
        if (name.isBlank()) return false
        val pm = ctx.packageManager
        val app = pm.getInstalledApplications(0).firstOrNull {
            pm.getLaunchIntentForPackage(it.packageName) != null &&
                pm.getApplicationLabel(it).toString().lowercase().contains(name)
        } ?: return false
        start(pm.getLaunchIntentForPackage(app.packageName)!!)
        return true
    }

    private fun torch(on: Boolean) {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.setTorchMode(cm.cameraIdList[0], on)
        } catch (e: Exception) { say("टॉर्च नहीं चली") }
    }

    private fun vol(up: Boolean) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
    }

    private fun findNumber(name: String): String? {
        if (name.isBlank()) return null
        return try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"), null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: SecurityException) { null }
    }

    private fun sendMessage(name: String, text: String, whatsapp: Boolean) {
        val digits = name.filter { it.isDigit() }
        val num = if (digits.length >= 5) digits else findNumber(name)
        if (num == null) { say("$name का नंबर नहीं मिला"); return }
        if (whatsapp) {
            var n = num.filter { it.isDigit() }
            if (n.length == 10) n = "91$n"
            start(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=" + Uri.encode(text))))
            Handler(Looper.getMainLooper()).postDelayed({
                val s = JarvisService.instance
                if (s?.clickText("Send") != true) s?.clickText("भेजें")
            }, 4000)
            say("व्हाट्सएप पर भेज रहा हूँ")
        } else {
            try {
                val sms = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
                          else @Suppress("DEPRECATION") SmsManager.getDefault()
                sms.sendTextMessage(num, null, text, null, null)
                say("मैसेज भेज दिया")
            } catch (e: Exception) { say("SMS नहीं गया, परमिशन देखें") }
        }
    }
}
