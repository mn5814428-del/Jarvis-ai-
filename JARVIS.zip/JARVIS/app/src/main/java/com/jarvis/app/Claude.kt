package com.jarvis.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

object Claude {
    // यहाँ अपनी API Key डालें (console.anthropic.com)
    const val API_KEY = "YOUR_API_KEY"
    private const val MODEL = "claude-sonnet-5-5"
    private const val SYSTEM =
        "तुम JARVIS हो, मेरे Android फोन का निजी असिस्टेंट। हमेशा हिंदी में, छोटा और सीधा जवाब दो। " +
        "फाइल, फोटो या स्क्रीन का टेक्स्ट मिले तो उसे ध्यान से समझकर बताओ।"

    private val http = OkHttpClient.Builder().readTimeout(90, TimeUnit.SECONDS).build()
    private val history = JSONArray()

    /** prompt: सवाल। mime + b64: फोटो या PDF (वैकल्पिक)। done: जवाब मिलने पर */
    fun ask(prompt: String, mime: String? = null, b64: String? = null, done: (String) -> Unit) {
        val content = JSONArray()
        if (mime != null && b64 != null) {
            val type = if (mime == "application/pdf") "document" else "image"
            content.put(JSONObject().put("type", type).put("source",
                JSONObject().put("type", "base64").put("media_type", mime).put("data", b64)))
        }
        content.put(JSONObject().put("type", "text").put("text", prompt))

        val msgs = JSONArray()
        for (i in 0 until history.length()) msgs.put(history.get(i))
        msgs.put(JSONObject().put("role", "user").put("content", content))

        val body = JSONObject()
            .put("model", MODEL).put("max_tokens", 800)
            .put("system", SYSTEM).put("messages", msgs)
            .toString().toRequestBody("application/json".toMediaType())

        val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", API_KEY)
            .header("anthropic-version", "2023-06-01")
            .post(body).build()

        thread {
            try {
                val res = JSONObject(http.newCall(req).execute().body!!.string())
                if (res.has("error")) {
                    done("API गलती: " + res.getJSONObject("error").optString("message")); return@thread
                }
                val arr = res.getJSONArray("content")
                val sb = StringBuilder()
                for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("text"))
                val ans = sb.toString()
                synchronized(history) {
                    history.put(JSONObject().put("role", "user").put("content", prompt.take(2000)))
                    history.put(JSONObject().put("role", "assistant").put("content", ans))
                    while (history.length() > 20) { history.remove(0); history.remove(0) }
                }
                done(ans)
            } catch (e: Exception) {
                done("इंटरनेट या API Key में दिक्कत है")
            }
        }
    }
}
