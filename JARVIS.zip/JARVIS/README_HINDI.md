# JARVIS Android - बनाने का तरीका

1. Android Studio → New Project → Empty Views Activity → Kotlin → Package `com.jarvis.app` → Min SDK 26
2. इस ज़िप की फाइलें अपने प्रोजेक्ट में उसी जगह कॉपी करें:
   - `app/src/main/AndroidManifest.xml` (बदल दें)
   - `app/src/main/res/xml/` (नया फोल्डर: accessibility_config.xml, file_paths.xml)
   - `app/src/main/java/com/jarvis/app/` में सारी .kt फाइलें (MainActivity.kt बदल दें)
3. `build_gradle_dependencies.txt` की लाइन build.gradle में जोड़ें, फिर Sync करें
4. `Claude.kt` में `YOUR_API_KEY` की जगह अपनी Key डालें
5. फोन USB से जोड़ें → Run
6. ऐप में बटन दबाकर: सारी परमिशन Allow, Overlay ON, Accessibility → JARVIS ON
7. अगर Accessibility धूसर हो: फोन Settings → Apps → JARVIS → ⋮ → "Allow restricted settings"
8. "Hey Jarvis मोड" ON करें, फिर बोलें: "Hey Jarvis" ... "जी बोलिए" ... कमांड

## कमांड
- open WhatsApp / यूट्यूब खोलो
- Rahul को call लगाओ / call 9876543210
- Rahul ko hello bhejo / Rahul ko whatsapp hello bhejo
- click Send / likho नमस्ते / scroll down
- टॉर्च चालू / volume up / वाईफाई / स्क्रीनशॉट / होम / पीछे / लॉक
- स्क्रीन पढ़ो (स्क्रीन का टेक्स्ट Claude समझाएगा)
- कैमरा से देखो (फोटो खींचकर Claude बताएगा)
- बाकी कुछ भी: सीधे Claude जवाब देगा
